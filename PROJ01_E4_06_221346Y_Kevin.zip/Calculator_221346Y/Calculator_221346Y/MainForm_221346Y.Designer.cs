﻿namespace Calculator_221346Y
{
    partial class MainForm_221346Y
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblID = new System.Windows.Forms.Label();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btnDot = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btnEqual = new System.Windows.Forms.Button();
            this.btnPlus = new System.Windows.Forms.Button();
            this.btnMinus = new System.Windows.Forms.Button();
            this.btnMulti = new System.Windows.Forms.Button();
            this.btnDivide = new System.Windows.Forms.Button();
            this.btnCE = new System.Windows.Forms.Button();
            this.btnPercent = new System.Windows.Forms.Button();
            this.btnSquareRoot = new System.Windows.Forms.Button();
            this.btnSquare = new System.Windows.Forms.Button();
            this.btnReciprocal = new System.Windows.Forms.Button();
            this.btnToggle = new System.Windows.Forms.Button();
            this.btnLog = new System.Windows.Forms.Button();
            this.btnLn = new System.Windows.Forms.Button();
            this.btnExpo = new System.Windows.Forms.Button();
            this.btnE = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblEquation = new System.Windows.Forms.Label();
            this.lblResults = new System.Windows.Forms.Label();
            this.txtEquation = new System.Windows.Forms.TextBox();
            this.btnC = new System.Windows.Forms.Button();
            this.btnMode = new System.Windows.Forms.Button();
            this.btnShift = new System.Windows.Forms.Button();
            this.lblMode = new System.Windows.Forms.Label();
            this.lblMode2 = new System.Windows.Forms.Label();
            this.pnlSci = new System.Windows.Forms.Panel();
            this.pnlStd = new System.Windows.Forms.Panel();
            this.btnMode2 = new System.Windows.Forms.Button();
            this.btnCopy = new System.Windows.Forms.Button();
            this.btnSound = new System.Windows.Forms.Button();
            this.lblSound = new System.Windows.Forms.Label();
            this.btnAnnounce = new System.Windows.Forms.Button();
            this.lblAnnounce = new System.Windows.Forms.Label();
            this.pnlSci.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(12, 9);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(184, 13);
            this.lblID.TabIndex = 0;
            this.lblID.Text = "Done By: Kevin (221346Y) Group: E4";
            this.lblID.Click += new System.EventHandler(this.lblID_Click);
            // 
            // btn1
            // 
            this.btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.Location = new System.Drawing.Point(12, 397);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(53, 47);
            this.btn1.TabIndex = 2;
            this.btn1.TabStop = false;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn2
            // 
            this.btn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.Location = new System.Drawing.Point(71, 397);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(53, 47);
            this.btn2.TabIndex = 3;
            this.btn2.TabStop = false;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn3
            // 
            this.btn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.Location = new System.Drawing.Point(130, 397);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(53, 47);
            this.btn3.TabIndex = 4;
            this.btn3.TabStop = false;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn4
            // 
            this.btn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4.Location = new System.Drawing.Point(12, 344);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(53, 47);
            this.btn4.TabIndex = 5;
            this.btn4.TabStop = false;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn5
            // 
            this.btn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.Location = new System.Drawing.Point(71, 344);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(53, 47);
            this.btn5.TabIndex = 6;
            this.btn5.TabStop = false;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn6
            // 
            this.btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.Location = new System.Drawing.Point(130, 344);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(53, 47);
            this.btn6.TabIndex = 7;
            this.btn6.TabStop = false;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn7
            // 
            this.btn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.Location = new System.Drawing.Point(12, 291);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(53, 47);
            this.btn7.TabIndex = 8;
            this.btn7.TabStop = false;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn8
            // 
            this.btn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.Location = new System.Drawing.Point(71, 291);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(53, 47);
            this.btn8.TabIndex = 9;
            this.btn8.TabStop = false;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn9
            // 
            this.btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.Location = new System.Drawing.Point(130, 291);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(53, 47);
            this.btn9.TabIndex = 10;
            this.btn9.TabStop = false;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btnDot
            // 
            this.btnDot.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDot.Location = new System.Drawing.Point(130, 450);
            this.btnDot.Name = "btnDot";
            this.btnDot.Size = new System.Drawing.Size(53, 47);
            this.btnDot.TabIndex = 11;
            this.btnDot.TabStop = false;
            this.btnDot.Text = ".";
            this.btnDot.UseVisualStyleBackColor = true;
            this.btnDot.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn0
            // 
            this.btn0.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn0.Location = new System.Drawing.Point(12, 450);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(112, 47);
            this.btn0.TabIndex = 12;
            this.btn0.TabStop = false;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btnEqual
            // 
            this.btnEqual.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEqual.Location = new System.Drawing.Point(189, 450);
            this.btnEqual.Name = "btnEqual";
            this.btnEqual.Size = new System.Drawing.Size(112, 47);
            this.btnEqual.TabIndex = 13;
            this.btnEqual.TabStop = false;
            this.btnEqual.Tag = "Equ";
            this.btnEqual.Text = "=";
            this.btnEqual.UseVisualStyleBackColor = true;
            this.btnEqual.Click += new System.EventHandler(this.btnEqual_Click);
            // 
            // btnPlus
            // 
            this.btnPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlus.Location = new System.Drawing.Point(189, 397);
            this.btnPlus.Name = "btnPlus";
            this.btnPlus.Size = new System.Drawing.Size(53, 47);
            this.btnPlus.TabIndex = 14;
            this.btnPlus.TabStop = false;
            this.btnPlus.Tag = "+";
            this.btnPlus.Text = "+";
            this.btnPlus.UseVisualStyleBackColor = true;
            this.btnPlus.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnMinus
            // 
            this.btnMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinus.Location = new System.Drawing.Point(248, 397);
            this.btnMinus.Name = "btnMinus";
            this.btnMinus.Size = new System.Drawing.Size(53, 47);
            this.btnMinus.TabIndex = 15;
            this.btnMinus.TabStop = false;
            this.btnMinus.Tag = "-";
            this.btnMinus.Text = "-";
            this.btnMinus.UseVisualStyleBackColor = true;
            this.btnMinus.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnMulti
            // 
            this.btnMulti.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMulti.Location = new System.Drawing.Point(189, 344);
            this.btnMulti.Name = "btnMulti";
            this.btnMulti.Size = new System.Drawing.Size(53, 47);
            this.btnMulti.TabIndex = 16;
            this.btnMulti.TabStop = false;
            this.btnMulti.Tag = "×";
            this.btnMulti.Text = "×";
            this.btnMulti.UseVisualStyleBackColor = true;
            this.btnMulti.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnDivide
            // 
            this.btnDivide.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDivide.Location = new System.Drawing.Point(248, 344);
            this.btnDivide.Name = "btnDivide";
            this.btnDivide.Size = new System.Drawing.Size(53, 47);
            this.btnDivide.TabIndex = 17;
            this.btnDivide.TabStop = false;
            this.btnDivide.Tag = "÷";
            this.btnDivide.Text = "÷";
            this.btnDivide.UseVisualStyleBackColor = true;
            this.btnDivide.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnCE
            // 
            this.btnCE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnCE.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCE.Location = new System.Drawing.Point(248, 238);
            this.btnCE.Name = "btnCE";
            this.btnCE.Size = new System.Drawing.Size(53, 47);
            this.btnCE.TabIndex = 18;
            this.btnCE.TabStop = false;
            this.btnCE.Tag = "CE";
            this.btnCE.Text = "CE";
            this.btnCE.UseVisualStyleBackColor = false;
            this.btnCE.Click += new System.EventHandler(this.btnCE_Click);
            // 
            // btnPercent
            // 
            this.btnPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPercent.Location = new System.Drawing.Point(189, 291);
            this.btnPercent.Name = "btnPercent";
            this.btnPercent.Size = new System.Drawing.Size(53, 47);
            this.btnPercent.TabIndex = 19;
            this.btnPercent.TabStop = false;
            this.btnPercent.Tag = "%";
            this.btnPercent.Text = "%";
            this.btnPercent.UseVisualStyleBackColor = true;
            this.btnPercent.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnSquareRoot
            // 
            this.btnSquareRoot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSquareRoot.Location = new System.Drawing.Point(0, 53);
            this.btnSquareRoot.Name = "btnSquareRoot";
            this.btnSquareRoot.Size = new System.Drawing.Size(53, 47);
            this.btnSquareRoot.TabIndex = 20;
            this.btnSquareRoot.TabStop = false;
            this.btnSquareRoot.Tag = "SquareRoot";
            this.btnSquareRoot.Text = "√";
            this.btnSquareRoot.UseVisualStyleBackColor = true;
            this.btnSquareRoot.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnSquare
            // 
            this.btnSquare.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSquare.Location = new System.Drawing.Point(59, 53);
            this.btnSquare.Name = "btnSquare";
            this.btnSquare.Size = new System.Drawing.Size(53, 47);
            this.btnSquare.TabIndex = 21;
            this.btnSquare.TabStop = false;
            this.btnSquare.Tag = "Square";
            this.btnSquare.Text = "x²";
            this.btnSquare.UseVisualStyleBackColor = true;
            this.btnSquare.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnReciprocal
            // 
            this.btnReciprocal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReciprocal.Location = new System.Drawing.Point(118, 53);
            this.btnReciprocal.Name = "btnReciprocal";
            this.btnReciprocal.Size = new System.Drawing.Size(53, 47);
            this.btnReciprocal.TabIndex = 22;
            this.btnReciprocal.TabStop = false;
            this.btnReciprocal.Tag = "Reciprocal";
            this.btnReciprocal.Text = "1/x";
            this.btnReciprocal.UseVisualStyleBackColor = true;
            this.btnReciprocal.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnToggle
            // 
            this.btnToggle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnToggle.Location = new System.Drawing.Point(177, 53);
            this.btnToggle.Name = "btnToggle";
            this.btnToggle.Size = new System.Drawing.Size(53, 47);
            this.btnToggle.TabIndex = 23;
            this.btnToggle.TabStop = false;
            this.btnToggle.Tag = "ToggleSign";
            this.btnToggle.Text = "±";
            this.btnToggle.UseVisualStyleBackColor = true;
            this.btnToggle.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnLog
            // 
            this.btnLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLog.Location = new System.Drawing.Point(0, 0);
            this.btnLog.Name = "btnLog";
            this.btnLog.Size = new System.Drawing.Size(53, 47);
            this.btnLog.TabIndex = 24;
            this.btnLog.TabStop = false;
            this.btnLog.Tag = "Log10";
            this.btnLog.Text = "Log10";
            this.btnLog.UseVisualStyleBackColor = true;
            this.btnLog.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnLn
            // 
            this.btnLn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLn.Location = new System.Drawing.Point(59, 0);
            this.btnLn.Name = "btnLn";
            this.btnLn.Size = new System.Drawing.Size(53, 47);
            this.btnLn.TabIndex = 25;
            this.btnLn.TabStop = false;
            this.btnLn.Tag = "Ln";
            this.btnLn.Text = "Ln";
            this.btnLn.UseVisualStyleBackColor = true;
            this.btnLn.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnExpo
            // 
            this.btnExpo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExpo.Location = new System.Drawing.Point(118, 0);
            this.btnExpo.Name = "btnExpo";
            this.btnExpo.Size = new System.Drawing.Size(53, 47);
            this.btnExpo.TabIndex = 26;
            this.btnExpo.TabStop = false;
            this.btnExpo.Tag = "Exponentiate";
            this.btnExpo.Text = "10˟";
            this.btnExpo.UseVisualStyleBackColor = true;
            this.btnExpo.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnE
            // 
            this.btnE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnE.Location = new System.Drawing.Point(177, 0);
            this.btnE.Name = "btnE";
            this.btnE.Size = new System.Drawing.Size(53, 47);
            this.btnE.TabIndex = 27;
            this.btnE.TabStop = false;
            this.btnE.Tag = "Exponential";
            this.btnE.Text = "e˟";
            this.btnE.UseVisualStyleBackColor = true;
            this.btnE.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(248, 185);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(53, 47);
            this.btnBack.TabIndex = 31;
            this.btnBack.TabStop = false;
            this.btnBack.Tag = "";
            this.btnBack.Text = "←";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblEquation
            // 
            this.lblEquation.AutoSize = true;
            this.lblEquation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEquation.Location = new System.Drawing.Point(24, 24);
            this.lblEquation.Name = "lblEquation";
            this.lblEquation.Size = new System.Drawing.Size(0, 20);
            this.lblEquation.TabIndex = 32;
            // 
            // lblResults
            // 
            this.lblResults.BackColor = System.Drawing.Color.Green;
            this.lblResults.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResults.Location = new System.Drawing.Point(12, 70);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(289, 54);
            this.lblResults.TabIndex = 33;
            this.lblResults.Text = "0";
            this.lblResults.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtEquation
            // 
            this.txtEquation.BackColor = System.Drawing.Color.Green;
            this.txtEquation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEquation.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEquation.ForeColor = System.Drawing.Color.LightGray;
            this.txtEquation.Location = new System.Drawing.Point(12, 51);
            this.txtEquation.Name = "txtEquation";
            this.txtEquation.Size = new System.Drawing.Size(289, 23);
            this.txtEquation.TabIndex = 34;
            // 
            // btnC
            // 
            this.btnC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC.Location = new System.Drawing.Point(248, 291);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(53, 47);
            this.btnC.TabIndex = 35;
            this.btnC.TabStop = false;
            this.btnC.Tag = "C";
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = false;
            this.btnC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // btnMode
            // 
            this.btnMode.BackColor = System.Drawing.Color.Red;
            this.btnMode.Location = new System.Drawing.Point(12, 128);
            this.btnMode.Name = "btnMode";
            this.btnMode.Size = new System.Drawing.Size(53, 23);
            this.btnMode.TabIndex = 36;
            this.btnMode.TabStop = false;
            this.btnMode.Text = "Sci";
            this.btnMode.UseVisualStyleBackColor = false;
            this.btnMode.Click += new System.EventHandler(this.btnMode_Click);
            // 
            // btnShift
            // 
            this.btnShift.BackColor = System.Drawing.Color.Cyan;
            this.btnShift.Location = new System.Drawing.Point(71, 128);
            this.btnShift.Name = "btnShift";
            this.btnShift.Size = new System.Drawing.Size(53, 23);
            this.btnShift.TabIndex = 37;
            this.btnShift.TabStop = false;
            this.btnShift.Text = "Shift";
            this.btnShift.UseVisualStyleBackColor = false;
            this.btnShift.Click += new System.EventHandler(this.btnShift_Click);
            // 
            // lblMode
            // 
            this.lblMode.AutoSize = true;
            this.lblMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMode.Location = new System.Drawing.Point(16, 28);
            this.lblMode.Name = "lblMode";
            this.lblMode.Size = new System.Drawing.Size(75, 20);
            this.lblMode.TabIndex = 39;
            this.lblMode.Text = "Standard";
            // 
            // lblMode2
            // 
            this.lblMode2.AutoSize = true;
            this.lblMode2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMode2.Location = new System.Drawing.Point(123, 28);
            this.lblMode2.Name = "lblMode2";
            this.lblMode2.Size = new System.Drawing.Size(60, 20);
            this.lblMode2.TabIndex = 40;
            this.lblMode2.Text = "Radian";
            // 
            // pnlSci
            // 
            this.pnlSci.Controls.Add(this.pnlStd);
            this.pnlSci.Controls.Add(this.btnLog);
            this.pnlSci.Controls.Add(this.btnSquareRoot);
            this.pnlSci.Controls.Add(this.btnLn);
            this.pnlSci.Controls.Add(this.btnSquare);
            this.pnlSci.Controls.Add(this.btnExpo);
            this.pnlSci.Controls.Add(this.btnReciprocal);
            this.pnlSci.Controls.Add(this.btnE);
            this.pnlSci.Controls.Add(this.btnToggle);
            this.pnlSci.Location = new System.Drawing.Point(12, 185);
            this.pnlSci.Name = "pnlSci";
            this.pnlSci.Size = new System.Drawing.Size(230, 100);
            this.pnlSci.TabIndex = 41;
            // 
            // pnlStd
            // 
            this.pnlStd.Location = new System.Drawing.Point(0, 0);
            this.pnlStd.Name = "pnlStd";
            this.pnlStd.Size = new System.Drawing.Size(230, 100);
            this.pnlStd.TabIndex = 42;
            // 
            // btnMode2
            // 
            this.btnMode2.BackColor = System.Drawing.Color.Yellow;
            this.btnMode2.Location = new System.Drawing.Point(130, 128);
            this.btnMode2.Name = "btnMode2";
            this.btnMode2.Size = new System.Drawing.Size(53, 23);
            this.btnMode2.TabIndex = 38;
            this.btnMode2.TabStop = false;
            this.btnMode2.Text = "Deg";
            this.btnMode2.UseVisualStyleBackColor = false;
            this.btnMode2.Click += new System.EventHandler(this.btnMode2_Click);
            // 
            // btnCopy
            // 
            this.btnCopy.BackColor = System.Drawing.Color.Fuchsia;
            this.btnCopy.Location = new System.Drawing.Point(189, 128);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(53, 23);
            this.btnCopy.TabIndex = 42;
            this.btnCopy.TabStop = false;
            this.btnCopy.Text = "Copy";
            this.btnCopy.UseVisualStyleBackColor = false;
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // btnSound
            // 
            this.btnSound.BackColor = System.Drawing.Color.Gray;
            this.btnSound.Location = new System.Drawing.Point(248, 127);
            this.btnSound.Name = "btnSound";
            this.btnSound.Size = new System.Drawing.Size(53, 23);
            this.btnSound.TabIndex = 43;
            this.btnSound.TabStop = false;
            this.btnSound.Text = "B Off";
            this.btnSound.UseVisualStyleBackColor = false;
            this.btnSound.Click += new System.EventHandler(this.btnSound_Click);
            // 
            // lblSound
            // 
            this.lblSound.AutoSize = true;
            this.lblSound.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSound.Location = new System.Drawing.Point(219, 9);
            this.lblSound.Name = "lblSound";
            this.lblSound.Size = new System.Drawing.Size(82, 20);
            this.lblSound.TabIndex = 44;
            this.lblSound.Text = "Button On";
            this.lblSound.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnAnnounce
            // 
            this.btnAnnounce.BackColor = System.Drawing.Color.Gray;
            this.btnAnnounce.Location = new System.Drawing.Point(248, 156);
            this.btnAnnounce.Name = "btnAnnounce";
            this.btnAnnounce.Size = new System.Drawing.Size(53, 23);
            this.btnAnnounce.TabIndex = 45;
            this.btnAnnounce.TabStop = false;
            this.btnAnnounce.Text = "A Off";
            this.btnAnnounce.UseVisualStyleBackColor = false;
            this.btnAnnounce.Click += new System.EventHandler(this.btnAnnounce_Click);
            // 
            // lblAnnounce
            // 
            this.lblAnnounce.AutoSize = true;
            this.lblAnnounce.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnnounce.Location = new System.Drawing.Point(189, 28);
            this.lblAnnounce.Name = "lblAnnounce";
            this.lblAnnounce.Size = new System.Drawing.Size(112, 20);
            this.lblAnnounce.TabIndex = 46;
            this.lblAnnounce.Text = "Announcer On";
            this.lblAnnounce.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MainForm_221346Y
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(308, 506);
            this.Controls.Add(this.lblAnnounce);
            this.Controls.Add(this.btnAnnounce);
            this.Controls.Add(this.lblSound);
            this.Controls.Add(this.btnSound);
            this.Controls.Add(this.btnCopy);
            this.Controls.Add(this.pnlSci);
            this.Controls.Add(this.lblMode2);
            this.Controls.Add(this.lblMode);
            this.Controls.Add(this.btnMode2);
            this.Controls.Add(this.btnShift);
            this.Controls.Add(this.btnMode);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.txtEquation);
            this.Controls.Add(this.lblResults);
            this.Controls.Add(this.lblEquation);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnPercent);
            this.Controls.Add(this.btnCE);
            this.Controls.Add(this.btnDivide);
            this.Controls.Add(this.btnMulti);
            this.Controls.Add(this.btnMinus);
            this.Controls.Add(this.btnPlus);
            this.Controls.Add(this.btnEqual);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btnDot);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.lblID);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MinimizeBox = false;
            this.Name = "MainForm_221346Y";
            this.Text = "Calculator";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MainForm_221346Y_KeyPress);
            this.pnlSci.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btnDot;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btnEqual;
        private System.Windows.Forms.Button btnPlus;
        private System.Windows.Forms.Button btnMinus;
        private System.Windows.Forms.Button btnMulti;
        private System.Windows.Forms.Button btnDivide;
        private System.Windows.Forms.Button btnCE;
        private System.Windows.Forms.Button btnPercent;
        private System.Windows.Forms.Button btnSquareRoot;
        private System.Windows.Forms.Button btnSquare;
        private System.Windows.Forms.Button btnReciprocal;
        private System.Windows.Forms.Button btnToggle;
        private System.Windows.Forms.Button btnLog;
        private System.Windows.Forms.Button btnLn;
        private System.Windows.Forms.Button btnExpo;
        private System.Windows.Forms.Button btnE;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblEquation;
        private System.Windows.Forms.Label lblResults;
        private System.Windows.Forms.TextBox txtEquation;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Button btnMode;
        private System.Windows.Forms.Button btnShift;
        private System.Windows.Forms.Label lblMode;
        private System.Windows.Forms.Label lblMode2;
        private System.Windows.Forms.Panel pnlSci;
        private System.Windows.Forms.Panel pnlStd;
        private System.Windows.Forms.Button btnMode2;
        private System.Windows.Forms.Button btnCopy;
        private System.Windows.Forms.Button btnSound;
        private System.Windows.Forms.Label lblSound;
        private System.Windows.Forms.Button btnAnnounce;
        private System.Windows.Forms.Label lblAnnounce;
    }
}

