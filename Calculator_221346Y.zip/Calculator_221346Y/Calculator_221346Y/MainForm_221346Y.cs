﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Calculator_221346Y
{

    public partial class MainForm_221346Y : Form
    {
        private string equation = ""; //create a variable to store the equation
        public MainForm_221346Y()
        {
            InitializeComponent();
            txtResults.Enabled = false;
            lblEquation.Font = new Font(lblEquation.Font.FontFamily, 9f);
            lblEquation.ForeColor = Color.LightGray;
        }

        private void lblID_Click(object sender, EventArgs e)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            var attribute = (GuidAttribute)assembly.GetCustomAttributes(typeof(GuidAttribute), true)[0];
            Clipboard.SetText(attribute.Value.ToString());
        }

        private void txtResults_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            string temp = txtResults.Text;
            if (temp == "0")
                temp = "";
            temp += '9';
            txtResults.Text = temp;
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            string temp = txtResults.Text;
            if (temp == "0")
                temp = "";
            temp += '8';
            txtResults.Text = temp;
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            string temp = txtResults.Text;
            if (temp == "0")
                temp = "";
            temp += '7';
            txtResults.Text = temp;
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            string temp = txtResults.Text;
            if (temp == "0")
                temp = "";
            temp += '6';
            txtResults.Text = temp;
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            string temp = txtResults.Text;
            if (temp == "0")
                temp = "";
            temp += '5';
            txtResults.Text = temp;
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            string temp = txtResults.Text;
            if (temp == "0")
                temp = "";
            temp += '4';
            txtResults.Text = temp;
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            string temp = txtResults.Text;
            if (temp == "0")
                temp = "";
            temp += '3';
            txtResults.Text = temp;
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            string temp = txtResults.Text;
            if (temp == "0")
                temp = "";
            temp += '2';
            txtResults.Text = temp;
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            string temp = txtResults.Text;
            if (temp == "0")
                temp = "";
            temp += '1';
            txtResults.Text = temp;
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            string temp = txtResults.Text;
            if (temp == "0")
                temp = "";
            temp += '0';
            txtResults.Text = temp;
        }

        private void btnDot_Click(object sender, EventArgs e)
        {
            string temp = txtResults.Text;
            if (!temp.Contains('.'))
            {
                temp += '.';
            }
            txtResults.Text = temp;
        }

        private void numPad_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Button btn = (System.Windows.Forms.Button)sender;
            string num = btn.Text;
            string temp = txtResults.Text;
            equation += num;
            lblEquation.Text = equation;
            if (flagOpPressed == true)
            {
                temp = "";
                flagOpPressed = false;
            }

            switch (num)
            {
                case ".":
                    if (!temp.Contains('.'))
                    {
                        temp += '.';
                    }
                    break;
                default:
                    if (temp == "0")
                        temp = "";
                    temp += num;
                    break;
            }
            txtResults.Text = temp;
        }

        string opr = "";
        double operand = 0;
        private void btnEqual_Click(object sender, EventArgs e)
        {
            double operand2 = Double.Parse(txtResults.Text);
            switch (opr)
            {
                case "Add":
                    operand = operand + operand2;
                    txtResults.Text = operand.ToString();
                    break;

                case "Minus":
                    operand = operand - operand2;
                    txtResults.Text = operand.ToString();
                    break;

                case "Multiply":
                    operand = operand * operand2;
                    txtResults.Text = operand.ToString();
                    break;

                case "Divide":
                    operand = operand / operand2;
                    txtResults.Text = operand.ToString();
                    break;

                case "Modulus":
                    operand = operand % operand2;
                    txtResults.Text = operand.ToString();
                    break;

                case "Square":
                    operand = Math.Pow(operand2, 2);
                    txtResults.Text = operand.ToString();
                    break;

                case "SquareRoot":
                    operand = Math.Sqrt(operand2);
                    txtResults.Text = operand.ToString();
                    break;

                case "Reciprocal":
                    operand = 1 / operand2;
                    txtResults.Text = operand.ToString();
                    break;

                case "ToggleSign":
                    operand = -operand2;
                    txtResults.Text = operand.ToString();
                    break;

                case "Log10":
                    operand = Math.Log10(operand2);
                    txtResults.Text = operand.ToString();
                    break;

                case "Ln":
                    operand = Math.Log(operand2);
                    txtResults.Text = operand.ToString();
                    break;

                case "Exponentiate":
                    operand = Math.Pow(10, operand2);
                    txtResults.Text = operand.ToString();
                    break;

                case "Exponential":
                    operand = Math.Exp(operand2);
                    txtResults.Text = operand.ToString();
                    break;

                case "Sin":
                    operand = Math.Sin(operand2);
                    txtResults.Text = operand.ToString();
                    break;

                case "Cos":
                    operand = Math.Cos(operand2);
                    txtResults.Text = operand.ToString();
                    break;

                case "Tan":
                    operand = Math.Tan(operand2);
                    txtResults.Text = operand.ToString();
                    break;

                default:
                    break;
            }
            opr = "";
        }

        bool flagOpPressed = false;
        private void operator_Click(object sender, EventArgs e)
        {
            btnEqual.PerformClick();
            operand = Double.Parse(txtResults.Text);
            System.Windows.Forms.Button btn = (System.Windows.Forms.Button)sender;
            string op = btn.Tag.ToString();

            if (equation.Length > 0 && !IsOperator(equation[equation.Length - 1]))
            {
                equation += op;
                lblEquation.Text = equation;
            }
            flagOpPressed = true;
        }

        private bool IsOperator(char c)
        {
            return (c == '+' || c == '-' || c == '*' || c == '/');
        }

        private void btnCE_Click(object sender, EventArgs e)
        {
            opr = "";
            operand = 0;
            equation = "";
            flagOpPressed = false;
            txtResults.Text = "0";
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (txtResults.Text.Length > 0)
            {
                txtResults.Text = txtResults.Text.Substring(0, txtResults.Text.Length - 1);
            }

            if (txtResults.Text == string.Empty)
            {
                txtResults.Text = "0";
            }

            if (equation.Length > 0)
            {
                equation = equation.Substring(0, equation.Length - 1);
            }

            if (equation == string.Empty)
            {
                equation = "";
            }
        }

        private void MainForm_221346Y_Load(object sender, EventArgs e)
        {

        }
    }
}
